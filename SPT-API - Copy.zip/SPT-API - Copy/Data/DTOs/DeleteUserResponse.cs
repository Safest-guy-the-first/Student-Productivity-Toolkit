﻿namespace SPT_API.Data.DTOs
{
    public class DeleteUserResponse
    {
       public bool? Success { get; set; } = false;
        public string? Message { get; set; } = null;
    }
}
