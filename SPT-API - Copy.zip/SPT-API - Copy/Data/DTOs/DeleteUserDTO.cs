﻿namespace SPT_API.Data.DTOs
{
    public class DeleteUserDTO
    {
        public string _firstName {  get; set; }
        public string _lastName { get; set; }
        public string _studentUsername { get; set; }
        public string _studentPassword { get; set; }

    }
}
